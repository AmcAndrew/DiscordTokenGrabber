I am not responsible for anything that happens to your account.

If you have not installed python 3.9.5 than go to the link provided to install the correct version (https://www.python.org/downloads/release/python-395/).

If you have installed python than you can run the launcher file (launcher.py).